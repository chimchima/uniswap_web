import './App.css';

const Select = () => {
    return(
        <div >
            <select>
            <option id='' > Пункт 1 </option>
            <option id=''> Пункт 2 </option>
            <option id=''> Пункт 3 </option>
            <option id=''> Пункт 4 </option>
            <option id=''> Пункт 5 </option>
            <option id=''> Пункт 6 </option>
            <option id=''> Пункт 7 </option>
            
            </select>
        </div>
    )
}

export default Select;